package com.michael.libplayer.media.store;

/**
 * ICloseable
 */
public interface ICloseable {

    void close();

}

