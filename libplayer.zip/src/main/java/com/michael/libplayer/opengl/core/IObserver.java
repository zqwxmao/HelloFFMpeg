package com.michael.libplayer.opengl.core;


public interface IObserver<Type> {

    void onCall(Type type);

}
